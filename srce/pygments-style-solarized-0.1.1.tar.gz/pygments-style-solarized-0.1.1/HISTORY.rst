HISTORY
=======

0.1.1 (2013.09.29)
* fix some typos, thank you jurriaan, nicolalamacchia!

0.1.0 (2012.09.17)
------------------
* first release
