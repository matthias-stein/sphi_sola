AUTHORS
=======

* Shoji KUMAGAI <take.this.2.your.grave at gmail.com>


Report bugs, typos and pull requests
------------------------------------
* @jurriaan
* @nicolalamacchia

Thanks to your contribution!
